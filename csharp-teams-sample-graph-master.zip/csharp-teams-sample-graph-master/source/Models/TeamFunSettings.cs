﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Microsoft_Teams_Graph_RESTAPIs_Connect.Models
{
    public class TeamFunSettings
    {
        public Boolean allowGiphy { get; set; }
        public string giphyContentRating { get; set; }
    }
}